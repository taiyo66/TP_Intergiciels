# kafka-producer-consumer-exemple
Exemple consumer &amp; producer for kafka
