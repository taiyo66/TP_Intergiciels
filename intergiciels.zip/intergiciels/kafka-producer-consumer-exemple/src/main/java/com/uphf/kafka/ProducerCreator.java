package com.uphf.kafka;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;


public class ProducerCreator {
	public static Producer<String, String> createProducer() {
		Properties props = new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, IKafkaConstants.KAFKA_BROKERS);
		props.put(ProducerConfig.CLIENT_ID_CONFIG, IKafkaConstants.CLIENT_ID);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

		// SSL configurations
		props.put("security.protocol", IKafkaConstants.SSL_PROTOCOL);
		props.put("ssl.keystore.location", IKafkaConstants.SSL_KEYSTORE_PRODUCER_LOCATION);
		props.put("ssl.keystore.password", IKafkaConstants.SSL_KEYSTORE_PASSWORD);
		props.put("ssl.key.password", IKafkaConstants.SSL_KEY_PASSWORD);
		props.put("ssl.truststore.location", IKafkaConstants.SSL_TRUSTSTORE_PRODUCER_LOCATION);
		props.put("ssl.truststore.password", IKafkaConstants.SSL_TRUSTSTORE_PASSWORD);

		return new KafkaProducer<>(props);
	}
}